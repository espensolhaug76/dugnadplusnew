import React, { useState, useEffect } from 'react';

interface Stats {
  totalShifts: number;
  assignedShifts: number;
  completedShifts: number;
  pendingShifts: number;
}

export const CoordinatorDashboard: React.FC = () => {
  const [stats, setStats] = useState<Stats>({
    totalShifts: 0,
    assignedShifts: 0,
    completedShifts: 0,
    pendingShifts: 0,
  });
  const [clubName, setClubName] = useState('Min Klubb');
  const [teamName, setTeamName] = useState('');

  useEffect(() => {
    // Load club and team info
    const storedClub = localStorage.getItem('dugnad_club');
    const storedTeam = localStorage.getItem('dugnad_current_team');
    
    if (storedClub) {
      const club = JSON.parse(storedClub);
      setClubName(club.name);
    }
    
    if (storedTeam) {
      const team = JSON.parse(storedTeam);
      setTeamName(team.name);
    }

    // Calculate stats from events
    const storedEvents = localStorage.getItem('dugnad_events');
    if (storedEvents) {
      const events = JSON.parse(storedEvents);
      const totalShifts = events.reduce((sum: number, event: any) => sum + (event.shifts?.length || 0), 0);
      const assignedShifts = events.reduce((sum: number, event: any) => 
        sum + (event.shifts?.filter((s: any) => s.status === 'filled' || s.status === 'confirmed').length || 0), 0
      );
      const completedShifts = events.reduce((sum: number, event: any) => 
        sum + (event.shifts?.filter((s: any) => s.status === 'completed').length || 0), 0
      );

      setStats({
        totalShifts,
        assignedShifts,
        completedShifts,
        pendingShifts: totalShifts - assignedShifts,
      });
    }
  }, []);

  const navigate = (path: string) => {
    window.location.href = path;
  };

  return (
    <div style={{ minHeight: '100vh', display: 'flex', background: 'var(--background)' }}>
      {/* Sidebar */}
      <div className="sidebar">
        <div style={{ marginBottom: '32px' }}>
          <h2 style={{ fontSize: '20px', fontWeight: '700', color: 'var(--text-primary)' }}>
            {clubName}
          </h2>
          {teamName && (
            <p style={{ fontSize: '14px', color: 'var(--text-secondary)', marginTop: '4px' }}>
              {teamName}
            </p>
          )}
        </div>

        <nav style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
          <button className="sidebar-nav-item active" onClick={() => navigate('/coordinator-dashboard')}>
            <span style={{ fontSize: '20px' }}>📊</span>
            Dashboard
          </button>
          <button className="sidebar-nav-item" onClick={() => navigate('/events-list')}>
            <span style={{ fontSize: '20px' }}>📅</span>
            Mine arrangementer
          </button>
          <button className="sidebar-nav-item" onClick={() => navigate('/manage-families')}>
            <span style={{ fontSize: '20px' }}>👨‍👩‍👧‍👦</span>
            Familier
          </button>
          <button className="sidebar-nav-item" onClick={() => navigate('/import-families')}>
            <span style={{ fontSize: '20px' }}>📤</span>
            Importer familier
          </button>
        </nav>
      </div>

      {/* Main Content */}
      <div className="main-content">
        {/* Hero Section with Background */}
        <div
          style={{
            background: 'linear-gradient(135deg, #16a8b8 0%, #1298a6 100%)',
            borderRadius: 'var(--radius-lg)',
            padding: '48px',
            marginBottom: '32px',
            color: 'white',
          }}
        >
          <h1 style={{ fontSize: '32px', fontWeight: '700', marginBottom: '8px' }}>
            Dugnadsoversikt
          </h1>
          <p style={{ fontSize: '18px', opacity: 0.9 }}>
            Velkommen tilbake! Her er status for ditt lag.
          </p>
        </div>

        {/* Stats Cards */}
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))',
            gap: '24px',
            marginBottom: '32px',
          }}
        >
          <div className="stat-card">
            <div className="stat-card-icon">📅</div>
            <div className="stat-card-value">{stats.totalShifts}</div>
            <div className="stat-card-label">Totalt dugnadsvakter</div>
          </div>

          <div className="stat-card">
            <div className="stat-card-icon">✅</div>
            <div className="stat-card-value">{stats.assignedShifts}</div>
            <div className="stat-card-label">Tildelte vakter</div>
          </div>

          <div className="stat-card">
            <div className="stat-card-icon">🏆</div>
            <div className="stat-card-value">{stats.completedShifts}</div>
            <div className="stat-card-label">Fullførte vakter</div>
          </div>

          <div className="stat-card">
            <div className="stat-card-icon">⏰</div>
            <div className="stat-card-value">{stats.pendingShifts}</div>
            <div className="stat-card-label">Ventende vakter</div>
          </div>
        </div>

        {/* Action Buttons */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '16px' }}>
          <button
            onClick={() => navigate('/create-event')}
            className="btn btn-primary"
            style={{ padding: '20px', fontSize: '16px', justifyContent: 'flex-start' }}
          >
            <span style={{ fontSize: '24px' }}>🏃‍♂️</span>
            <span>Nytt arrangement</span>
          </button>

          <button
            onClick={() => navigate('/import-families')}
            className="btn"
            style={{
              padding: '20px',
              fontSize: '16px',
              background: 'white',
              border: '2px solid var(--border-color)',
              justifyContent: 'flex-start',
            }}
          >
            <span style={{ fontSize: '24px' }}>📤</span>
            <span>Last opp familier</span>
          </button>

          <button
            onClick={() => navigate('/events-list')}
            className="btn"
            style={{
              padding: '20px',
              fontSize: '16px',
              background: 'white',
              border: '2px solid var(--border-color)',
              justifyContent: 'flex-start',
            }}
          >
            <span style={{ fontSize: '24px' }}>📋</span>
            <span>Se rapporter</span>
          </button>
        </div>
      </div>
    </div>
  );
};
