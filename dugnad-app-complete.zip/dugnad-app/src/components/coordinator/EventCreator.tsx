import React, { useState } from 'react';
import { DugnadEvent, DugnadShift, SPORT_SHIFT_SUGGESTIONS } from '../../types';

export const EventCreator: React.FC = () => {
  const [eventData, setEventData] = useState({
    eventName: '',
    date: '',
    startTime: '09:00',
    endTime: '15:00',
    location: '',
    sport: 'football',
  });

  const [shifts, setShifts] = useState<DugnadShift[]>([]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setEventData({
      ...eventData,
      [e.target.name]: e.target.value,
    });
  };

  const calculateDuration = () => {
    if (!eventData.startTime || !eventData.endTime) return 0;
    const start = parseInt(eventData.startTime.split(':')[0]);
    const end = parseInt(eventData.endTime.split(':')[0]);
    return end - start;
  };

  const handleSmartSuggestion = () => {
    const duration = calculateDuration();
    if (duration <= 0) {
      alert('Vennligst sett start- og sluttid først');
      return;
    }

    // Get shift suggestions for this sport
    const sportSuggestions = SPORT_SHIFT_SUGGESTIONS.find(s => s.sport === eventData.sport) || 
                            SPORT_SHIFT_SUGGESTIONS.find(s => s.sport === 'other')!;

    // Create suggested shifts (2x3 hours for 6+ hour events)
    const suggestedShifts: DugnadShift[] = [];
    const shiftDuration = duration >= 6 ? 3 : 2;
    const numberOfShifts = Math.ceil(duration / shiftDuration);

    for (let i = 0; i < numberOfShifts; i++) {
      for (const shiftType of sportSuggestions.commonShifts) {
        const startHour = parseInt(eventData.startTime.split(':')[0]) + (i * shiftDuration);
        const endHour = startHour + shiftDuration;

        suggestedShifts.push({
          id: Date.now().toString() + Math.random(),
          shiftType: shiftType,
          startTime: `${startHour.toString().padStart(2, '0')}:00`,
          endTime: `${endHour.toString().padStart(2, '0')}:00`,
          duration: shiftDuration,
          volunteersNeeded: 1,
          assignedCount: 0,
          status: 'open',
        });
      }
    }

    setShifts(suggestedShifts);
  };

  const handleAddShift = () => {
    const newShift: DugnadShift = {
      id: Date.now().toString(),
      shiftType: '',
      startTime: eventData.startTime,
      endTime: eventData.endTime,
      duration: calculateDuration(),
      volunteersNeeded: 1,
      assignedCount: 0,
      status: 'open',
    };
    setShifts([...shifts, newShift]);
  };

  const handleRemoveShift = (id: string) => {
    setShifts(shifts.filter(s => s.id !== id));
  };

  const handleSaveEvent = () => {
    if (!eventData.eventName || !eventData.date || shifts.length === 0) {
      alert('Vennligst fyll ut alle felt og legg til minst én vakt');
      return;
    }

    const newEvent: DugnadEvent = {
      id: Date.now().toString(),
      teamId: 'current_team',
      eventName: eventData.eventName,
      date: eventData.date,
      location: eventData.location,
      sport: eventData.sport,
      shifts: shifts,
      status: 'draft',
      points: shifts.length * 100,
      createdBy: 'current_user',
      createdAt: new Date().toISOString(),
      type: 'single',
    };

    // Save to localStorage
    const existing = localStorage.getItem('dugnad_events');
    const events = existing ? JSON.parse(existing) : [];
    events.push(newEvent);
    localStorage.setItem('dugnad_events', JSON.stringify(events));

    alert('Arrangement opprettet!');
    window.location.href = '/coordinator-dashboard';
  };

  return (
    <div style={{ minHeight: '100vh', display: 'flex', background: 'var(--background)' }}>
      <div className="sidebar">
        <button className="sidebar-nav-item" onClick={() => window.location.href = '/coordinator-dashboard'}>
          ← Tilbake
        </button>
      </div>

      <div className="main-content">
        <h1 style={{ fontSize: '32px', fontWeight: '700', marginBottom: '32px' }}>Opprett arrangement</h1>

        <div className="card" style={{ padding: '32px', marginBottom: '24px' }}>
          <h2 style={{ fontSize: '24px', fontWeight: '600', marginBottom: '24px' }}>Grunnleggende informasjon</h2>

          <div style={{ display: 'grid', gap: '20px' }}>
            <div>
              <label className="input-label">Arrangementsnavn *</label>
              <input
                type="text"
                name="eventName"
                value={eventData.eventName}
                onChange={handleChange}
                className="input"
                placeholder="F.eks. Hjemmekamp mot Strømsgodset"
              />
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
              <div>
                <label className="input-label">Dato *</label>
                <input
                  type="date"
                  name="date"
                  value={eventData.date}
                  onChange={handleChange}
                  className="input"
                />
              </div>

              <div>
                <label className="input-label">Idrett</label>
                <select name="sport" value={eventData.sport} onChange={handleChange} className="input">
                  <option value="football">⚽ Fotball</option>
                  <option value="handball">🤾 Håndball</option>
                  <option value="ishockey">🏒 Ishockey</option>
                  <option value="other">Annet</option>
                </select>
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
              <div>
                <label className="input-label">Starttid</label>
                <input
                  type="time"
                  name="startTime"
                  value={eventData.startTime}
                  onChange={handleChange}
                  className="input"
                />
              </div>

              <div>
                <label className="input-label">Sluttid</label>
                <input
                  type="time"
                  name="endTime"
                  value={eventData.endTime}
                  onChange={handleChange}
                  className="input"
                />
              </div>
            </div>

            <div>
              <label className="input-label">Sted</label>
              <input
                type="text"
                name="location"
                value={eventData.location}
                onChange={handleChange}
                className="input"
                placeholder="F.eks. Gjemselund Stadion"
              />
            </div>

            <button onClick={handleSmartSuggestion} className="btn btn-secondary">
              ✨ Smart forslag til vakter
            </button>
          </div>
        </div>

        {/* Shifts Section */}
        <div className="card" style={{ padding: '32px', marginBottom: '24px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px' }}>
            <h2 style={{ fontSize: '24px', fontWeight: '600' }}>Vakter ({shifts.length})</h2>
            <button onClick={handleAddShift} className="btn btn-primary">
              + Legg til vakt
            </button>
          </div>

          {shifts.length > 0 ? (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              {shifts.map((shift) => (
                <div
                  key={shift.id}
                  style={{
                    padding: '16px',
                    background: 'var(--background)',
                    borderRadius: 'var(--radius-md)',
                    display: 'flex',
                    gap: '16px',
                    alignItems: 'center',
                  }}
                >
                  <input
                    type="text"
                    value={shift.shiftType}
                    onChange={(e) => {
                      const updated = shifts.map(s => 
                        s.id === shift.id ? { ...s, shiftType: e.target.value } : s
                      );
                      setShifts(updated);
                    }}
                    className="input"
                    placeholder="Vaktype (f.eks. Kioskvakt)"
                    style={{ flex: 1 }}
                  />
                  <div style={{ width: '120px' }}>
                    {shift.startTime} - {shift.endTime}
                  </div>
                  <button
                    onClick={() => handleRemoveShift(shift.id)}
                    style={{
                      padding: '8px 16px',
                      background: 'var(--danger-color)',
                      color: 'white',
                      border: 'none',
                      borderRadius: 'var(--radius-md)',
                      cursor: 'pointer',
                    }}
                  >
                    Slett
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <p style={{ color: 'var(--text-secondary)', textAlign: 'center', padding: '32px' }}>
              Ingen vakter lagt til ennå. Bruk "Smart forslag" eller legg til manuelt.
            </p>
          )}
        </div>

        {/* Action Buttons */}
        <div style={{ display: 'flex', gap: '16px' }}>
          <button onClick={handleSaveEvent} className="btn btn-primary btn-large">
            Lagre arrangement
          </button>
          <button
            onClick={() => window.location.href = '/coordinator-dashboard'}
            className="btn btn-secondary btn-large"
          >
            Avbryt
          </button>
        </div>
      </div>
    </div>
  );
};
