// Dugnad+ TypeScript Types

export interface User {
  id: string;
  email: string;
  fullName: string;
  phone: string;
  role: 'coordinator' | 'family' | 'substitute';
  createdAt: string;
}

export interface Club {
  id: string;
  name: string;
  logoUrl?: string;
  createdBy: string;
  createdAt: string;
}

export interface Team {
  id: string;
  clubId: string;
  sport: string;
  gender: 'gutter' | 'jenter' | 'mixed';
  birthYear: number;
  name: string;
  createdAt: string;
}

export interface Family {
  id: string;
  familyName: string;
  primaryContactUserId: string;
  totalPoints: number;
  currentTier: 'basis' | 'aktiv' | 'premium' | 'vip';
  createdAt: string;
}

export interface FamilyMember {
  id: string;
  familyId: string;
  name: string;
  birthYear: number;
  role: 'parent' | 'child';
}

export interface TeamMember {
  id: string;
  teamId: string;
  familyMemberId: string;
}

export interface DugnadShift {
  id: string;
  shiftType: string;
  startTime: string;
  endTime: string;
  duration: number; // in hours
  volunteers Needed: number;
  assignedCount: number;
  status: 'open' | 'filled' | 'confirmed' | 'completed';
}

export interface DugnadEvent {
  id: string;
  teamId: string;
  eventName: string;
  date: string;
  location?: string;
  sport: string;
  shifts: DugnadShift[];
  status: 'draft' | 'published' | 'completed' | 'cancelled';
  points: number;
  createdBy: string;
  createdAt: string;
  type: 'single' | 'season' | 'multiday' | 'tournament';
}

export interface EventAssignment {
  id: string;
  eventId: string;
  shiftId: string;
  familyId: string;
  status: 'assigned' | 'confirmed' | 'completed' | 'swapped' | 'substitute';
  assignedAt: string;
  confirmedAt?: string;
  completedAt?: string;
}

export interface PointsTransaction {
  id: string;
  familyId: string;
  eventId?: string;
  points: number;
  type: 'earned' | 'bonus' | 'manual' | 'penalty';
  description: string;
  createdAt: string;
}

export interface SubstituteRequest {
  id: string;
  eventId: string;
  shiftId: string;
  familyId: string;
  suggestedPayment: number;
  status: 'open' | 'accepted' | 'completed' | 'cancelled';
  acceptedBy?: string;
  createdAt: string;
}

export type TierLevel = 'basis' | 'aktiv' | 'premium' | 'vip';

export interface TierBenefits {
  tier: TierLevel;
  pointsRequired: number;
  benefits: string[];
  color: string;
}

export const TIER_LEVELS: TierBenefits[] = [
  {
    tier: 'basis',
    pointsRequired: 0,
    benefits: ['Grunnrabatter', 'Tilgang til vikar-markedsplass'],
    color: '#e2e8f0',
  },
  {
    tier: 'aktiv',
    pointsRequired: 100,
    benefits: ['Bedre rabatter', 'Prioritet ved bytter', 'Færre automatiske tildelinger'],
    color: '#bee3f8',
  },
  {
    tier: 'premium',
    pointsRequired: 300,
    benefits: ['Premium fordeler', 'VIP-arrangementer', 'Eksklusiv e sponsorrabatter'],
    color: '#fbb6ce',
  },
  {
    tier: 'vip',
    pointsRequired: 500,
    benefits: ['Maksimale fordeler', 'Minimale dugnadskrav', 'Alle sponsorrabatter'],
    color: '#fbd38d',
  },
];

export interface SportShiftSuggestion {
  sport: string;
  commonShifts: string[];
}

export const SPORT_SHIFT_SUGGESTIONS: SportShiftSuggestion[] = [
  {
    sport: 'football',
    commonShifts: ['Kioskvakt', 'Billettsalg', 'Fair play/kampvert', 'Ryddevakt', 'Sekretæriat'],
  },
  {
    sport: 'handball',
    commonShifts: ['Kioskvakt', 'Kampvert', 'Dommer', 'Sekretær', 'Ryddevakt'],
  },
  {
    sport: 'ishockey',
    commonShifts: ['Kioskvakt', 'Tidtaker', 'Speaker', 'Ryddevakt', 'Garderobe'],
  },
  {
    sport: 'other',
    commonShifts: ['Generell vakt', 'Arrangement', 'Transport', 'Utstyr', 'Ryddevakt'],
  },
];
